const express = require("express");
const app = express();
const cors = require("cors");
const port = 3042;
const { sha256 } = require("ethereum-cryptography/sha256");
const { keccak256 } = require("ethereum-cryptography/keccak");
const { hexToBytes, toHex, utf8ToBytes } = require("ethereum-cryptography/utils");

app.use(cors());
app.use(express.json());

const balances = {
  "0483a232dbefd4d2d851cca149acc8268c11336f06a24fc2dbaa42775db9bcd59bfa4ae94d75a47a4aaa46858f28a72418f3d3db8ddc4b71a4b687120d0234e0e1": 100, //6af138f0d87e9503a2965ebb06eaf48390a13d7071b9c6706a12f0cfd1d14381
  "04371fc58e23cf0d16ef5dfa805e347dcd76c8e64d5c356779319265225d2ae4204ff52e2190b8804cb1eb1e54ab230cf9ac8d3f9d7cdeb1c24085e7470d3dd983": 50, //8b815e0f717696fbbe63c360cd4c8e51176894f4ced863acb043aa7763250700
  "04983659fdabfe5cafbf6cc6270e80a4c8ce4a1d8b2fd37817fe3d81735a9d72fa30194bbdf207325e8f17f8da9ad348525745f38c419b90692a289bb71c978597": 75, //8d4adb52ed2bbfa956d8c6f369b26e6fcebee084eb5032ec631b9481687c83c4
};

app.get("/balance/:address", (req, res) => {
  const { address } = req.params;
  const balance = balances[address] || 0;
  res.send({ balance });
});

app.post("/send", (req, res) => {
  const { sender, recipient, amount } = req.body;

  setInitialBalance(sender);
  setInitialBalance(recipient);

  if (balances[sender] < amount) {
    res.status(400).send({ message: "Not enough funds!" });
  } else {
    balances[sender] -= amount;
    balances[recipient] += amount;
    res.send({ balance: balances[sender] });
  }
});

app.listen(port, () => {
  console.log(`Listening on port ${port}!`);
});

function setInitialBalance(address) {
  if (!balances[address]) {
    balances[address] = 0;
  }
}
